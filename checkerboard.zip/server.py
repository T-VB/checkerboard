from flask import Flask, render_template  
app = Flask(__name__)

'''
#1 - display 8 by 8 checkerboard
@app.route('/') 
def eight_by_eight():
    return render_template('index.html')
'''
#1 - display 8 by 8 checkerboard
@app.route('/') 
def eight_by_eight():
    return render_template('index.html', col=8, row=8, color1='blue', color2='yellow')

#2 - display 8 by 4 checkerboard
@app.route('/<int:x>') 
def eight_by_four(x):
    return render_template('index.html', col=8, row=x, color1='blue', color2='yellow')

#3 - display x by y checkerboard
@app.route('/<int:x>/<int:y>')
def x_by_y(x, y):
    return render_template('index.html', col=y, row=x, color1='blue', color2='yellow')

@app.route('/<int:x>/<int:y>/<string:c1>/<string:c2>')
def xy_color(x, y, c1, c2):
    return render_template('index.html', col=y, row=x, color1=c1, color2=c2)
if __name__=="__main__":   # Ensure this file is being run directly and not from a different module    
    app.run(debug=True)